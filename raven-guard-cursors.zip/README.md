# Raven Guard Cursor Pack
## Chapter XIX - Shadow Operations Division

**Victorus aut Mortis**

This cursor pack is themed after the Raven Guard Space Marine Chapter from Warhammer 40,000.

### Installation

1. Extract this archive
2. Run the installation script:
   ```bash
   chmod +x install.sh
   sudo ./install.sh
   ```

3. Add to your Hyprland config (~/.config/hypr/hyprland.conf):
   ```
   env = XCURSOR_THEME,raven-guard-cursors
   env = XCURSOR_SIZE,24
   exec-once = hyprctl setcursor raven-guard-cursors 24
   ```

4. Restart Hyprland

### Manual Installation

If you prefer manual installation:

```bash
# System-wide
sudo cp -r raven-guard-cursors /usr/share/icons/

# User-only
mkdir -p ~/.local/share/icons
cp -r raven-guard-cursors ~/.local/share/icons/
```

### Theme Colors

- Primary: #a0a0a0 (Raven Grey)
- Secondary: #505050 (Steel Grey)
- Background: #0d0d0d (Shadow Black)

### Credits

Created for the Raven Guard themed Hyprland desktop environment.

"We are the shadows, we are death."
