#!/bin/bash
# Raven Guard Cursor Installation Script
echo "========================================="
echo "Installing Raven Guard Cursors..."
echo "========================================="

if [ -d "/usr/share/icons/raven-guard-cursors" ]; then
    echo "Removing old installation..."
    sudo rm -rf /usr/share/icons/raven-guard-cursors
fi

echo "Installing to /usr/share/icons/..."
sudo cp -r raven-guard-cursors /usr/share/icons/

echo ""
echo "Installation complete!"
echo "To apply the cursor theme, add to your Hyprland config:"
echo ""
echo "env = XCURSOR_THEME,raven-guard-cursors"
echo "env = XCURSOR_SIZE,24"
echo "exec-once = hyprctl setcursor raven-guard-cursors 24"
echo ""
echo "Then restart Hyprland."
echo "========================================="
